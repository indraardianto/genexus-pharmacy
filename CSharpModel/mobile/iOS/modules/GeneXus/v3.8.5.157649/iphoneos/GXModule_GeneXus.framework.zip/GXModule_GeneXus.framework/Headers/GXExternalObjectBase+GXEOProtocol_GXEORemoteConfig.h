@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEORemoteConfig <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSDate * lastSuccessfulFetch NS_SWIFT_NAME(lastSuccessfulFetch);
@property(nonatomic, readonly) NSInteger lastFetchStatus NS_SWIFT_NAME(lastFetchStatus);

+ (BOOL)hasValue:(NSString *)key  NS_SWIFT_NAME(hasValue(_:));
+ (NSString *)getStringValue:(NSString *)key  NS_SWIFT_NAME(getStringValue(_:));
+ (NSInteger)getIntegerValue:(NSString *)key  NS_SWIFT_NAME(getIntegerValue(_:));
+ (int64_t)getDecimalValue:(NSString *)key  NS_SWIFT_NAME(getDecimalValue(_:));
+ (BOOL)getBooleanValue:(NSString *)key  NS_SWIFT_NAME(getBooleanValue(_:));
+ (NSDate *)getDateValue:(NSString *)key  NS_SWIFT_NAME(getDateValue(_:));
+ (NSDate *)getDateTimeValue:(NSString *)key  NS_SWIFT_NAME(getDateTimeValue(_:));
+ (BOOL)fetch NS_SWIFT_NAME(fetch());
+ (BOOL)apply NS_SWIFT_NAME(apply());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEORemoteConfig)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEORemoteConfig> gxEOClass_GXEORemoteConfig;

@end

NS_ASSUME_NONNULL_END
