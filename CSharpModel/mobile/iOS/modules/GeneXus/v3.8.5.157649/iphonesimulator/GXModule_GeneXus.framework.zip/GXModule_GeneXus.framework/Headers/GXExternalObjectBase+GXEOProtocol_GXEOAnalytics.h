@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@class genexus_common_SdtAnalyticsPurchase;

@protocol GXEOProtocol_GXEOAnalytics <NSObject>

- (instancetype)init;

+ (void)trackView:(NSString *)viewName  NS_SWIFT_NAME(trackView(_:));
+ (void)trackEvent:(NSString *)category :(NSString *)action :(NSString *)label :(NSDecimal)value  NS_SWIFT_NAME(trackEvent(_:_:_:_:));
+ (void)trackPurchase:(genexus_common_SdtAnalyticsPurchase *)purchaseInfo  NS_SWIFT_NAME(trackPurchase(_:));
+ (void)setUserId:(NSString *)userId  NS_SWIFT_NAME(setUserId(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOAnalytics)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOAnalytics> gxEOClass_GXEOAnalytics;

@end

NS_ASSUME_NONNULL_END
