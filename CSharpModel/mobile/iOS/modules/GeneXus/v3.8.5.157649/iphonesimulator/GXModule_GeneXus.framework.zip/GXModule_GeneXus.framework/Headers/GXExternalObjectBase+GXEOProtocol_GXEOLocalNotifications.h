@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOLocalNotifications <NSObject>

- (instancetype)init;

+ (NSInteger)createAlerts:(GXObjectCollection *)alerts  NS_SWIFT_NAME(createAlerts(_:));
+ (GXObjectCollection *)listAlerts NS_SWIFT_NAME(listAlerts());
+ (NSInteger)removeAlerts:(GXObjectCollection *)alerts  NS_SWIFT_NAME(removeAlerts(_:));
+ (NSInteger)removeAllAlerts NS_SWIFT_NAME(removeAllAlerts());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOLocalNotifications)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOLocalNotifications> gxEOClass_GXEOLocalNotifications;

@end

NS_ASSUME_NONNULL_END
