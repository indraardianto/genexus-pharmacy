@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEODynamicCall <NSObject>

- (instancetype)init;

+ (void)setOption:(NSString *)ObjectName :(NSString *)CallOption :(NSString *)Value  NS_SWIFT_NAME(setOption(_:_:_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEODynamicCall)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEODynamicCall> gxEOClass_GXEODynamicCall;

@end

NS_ASSUME_NONNULL_END
