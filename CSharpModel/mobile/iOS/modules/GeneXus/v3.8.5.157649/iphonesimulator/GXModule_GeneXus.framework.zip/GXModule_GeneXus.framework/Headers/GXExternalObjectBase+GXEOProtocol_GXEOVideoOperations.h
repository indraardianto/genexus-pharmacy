@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@class genexus_sd_media_SdtVideoConversionParameters;

@protocol GXEOProtocol_GXEOVideoOperations <NSObject>

- (instancetype)init;

+ (NSString *)applyconversions:(NSString *)video :(genexus_sd_media_SdtVideoConversionParameters *)convertions  NS_SWIFT_NAME(applyconversions(_:_:));
+ (NSString *)convertformat:(NSString *)video :(NSInteger)format  NS_SWIFT_NAME(convertformat(_:_:));
+ (NSString *)reducequality:(NSString *)video :(NSInteger)quality  NS_SWIFT_NAME(reducequality(_:_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOVideoOperations)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOVideoOperations> gxEOClass_GXEOVideoOperations;

@end

NS_ASSUME_NONNULL_END
