@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOAudioRecorderAPI <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) BOOL isRecording NS_SWIFT_NAME(isRecording);

+ (BOOL)start NS_SWIFT_NAME(start());
+ (NSString *)stop NS_SWIFT_NAME(stop());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOAudioRecorderAPI)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOAudioRecorderAPI> gxEOClass_GXEOAudioRecorderAPI;

@end

NS_ASSUME_NONNULL_END
